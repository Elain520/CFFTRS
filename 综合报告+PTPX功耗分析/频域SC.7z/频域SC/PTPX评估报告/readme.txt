switch_power_v.log、switch_power_h.log：测试了译码的整个过程。
switch_power_v14.log、switch_power_h14.log：仅测试译码的前14个周期（码字接收过程）。